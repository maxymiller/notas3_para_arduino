#include "maxymiller_lib/Wifi.h"

boolean Wifi::conecta(Preferences memoria) {
  WiFi.begin(
    WIFI_SSID,
    WIFI_PASSWORD
  );

  int loop = 0;
  while(WiFi.status() != WL_CONNECTED && loop < 30) {

    delay(500);
    loop++;
  }

  if(WiFi.status() == WL_CONNECTED) {
    memoria.begin("wifi", false);
    if(WIFI_SSID != memoria.getString("ssid", "") || WIFI_PASSWORD != memoria.getString("pass", "")) {
      memoria.putString("ssid", WIFI_SSID);
      memoria.putString("pass", WIFI_PASSWORD);
    }
    memoria.end();

    return true;
  }
  return false;
}
void Wifi::set(String ssid, String pass) {
  WIFI_SSID = ssid;
  WIFI_PASSWORD = pass;
}
void Wifi::list() {
  int quantidade = WiFi.scanNetworks();

  if(quantidade >= 0) {
    LIST_SSID_TAMANHO = quantidade;

    delete[] LIST_SSID;
    LIST_SSID = new String[quantidade];

    for (int i = 0; i < quantidade; i++) {
      LIST_SSID[i] = WiFi.SSID(i);

      int id = String(i).length();

      for(int t = 0; t <= 3; t++) {
        if(t == 0) {
          Serial.println(
            String(i)+
            ": "+
            WiFi.SSID(i)
          );
        }

        if(t != 1) {
          Serial.print("  ");
          for(int j = 0; j < id; j++) {
            Serial.print(" ");
          }
        }
      
        if(t == 1) {
          Serial.println("RSSI: "+String(WiFi.RSSI(i))+" dBm");
        }else if(t == 2){
          Serial.println("Canal: "+String(WiFi.channel(i)));
        }else if(t == 3){
          Serial.print("Segurança: ");
          if (WiFi.encryptionType(i) == WIFI_AUTH_OPEN) {
            Serial.println("Nenhuma");
          } else {
            Serial.println("Com senha");
          }
        }
      }
      Serial.println();
    }
  }else if(quantidade == -1) {
    Serial.println("ERROR WIFI: CODE "+String(quantidade)+" WIFI_SCAN_FAILED");
  }else if(quantidade == -2) {
    Serial.println("ERROR WIFI: CODE "+String(quantidade)+" WIFI_SCAN_RUNNING");
  }else{
    Serial.println("ERROR WIFI: CODE "+String(quantidade));
  }
  WiFi.scanDelete();
}
String Wifi::getSSID(int SSID_N) {
  if(0 <= SSID_N && SSID_N < LIST_SSID_TAMANHO) {
    return LIST_SSID[SSID_N];
  }
  return "";
}
String Wifi::getIp() {
  return WiFi.localIP().toString();
}
String Wifi::getConecta() {
  if(WiFi.status() == WL_CONNECTED) {
    return "tá conectado";
  }else{
    return "não está conectado";
  }
}
String Wifi::getRssi() {
  return String(WiFi.RSSI())+" dBm";
}
void Wifi::remoreSave(Preferences memoria) {
  memoria.begin("wifi", false);
  memoria.putString("ssid", "");
  memoria.putString("pass", "");
  memoria.end();

  WIFI_SSID = "";
  WIFI_PASSWORD = "";

  WiFi.disconnect(true);
}