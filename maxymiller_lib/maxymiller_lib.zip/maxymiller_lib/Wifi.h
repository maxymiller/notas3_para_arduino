#ifndef WIFI_H
#define WIFI_H

#include <Arduino.h>
#include <WiFi.h>
#include <Preferences.h>

class Wifi {
private:
  String WIFI_SSID = "";
  String WIFI_PASSWORD = "";
  String* LIST_SSID = nullptr;
  int LIST_SSID_TAMANHO = 0;
public:
  boolean conecta(Preferences memoria);
  void set(String ssid, String pass);
  void list();
  String getSSID(int SSID_N);
  String getIp();
  String getConecta();
  String getRssi();
  void remoreSave(Preferences memoria);
};

#endif