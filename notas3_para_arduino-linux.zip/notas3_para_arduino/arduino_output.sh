#!/bin/bash

arduino_input="$(cat memoria/arduino_input)"

#if [ -e "$arduino_input" ]; then
    #while true; do
        #cat "$arduino_input" > "memoria/arduino_output"
        #sleep 1
    #done
    
    arduino_on=0
    while IFS= read -r linha; do
        #echo "$linha" > "memoria/arduino_output"

        linha="${linha%$'\r'}"

        if [[ "$linha" == "LIGADO" || "$linha" == "READY" || "$linha" == "ERROR" ]]; then
            arduino_on=1
        fi
        echo "$(echo -e "\r")[$0] ($arduino_on): $linha$(echo -e "\r")" 1>&2
        if [ "$arduino_on" == "1" ]; then
            echo "$linha"
        fi
    done
#else
    #echo "[$0] error input: $arduino_input"
#fi