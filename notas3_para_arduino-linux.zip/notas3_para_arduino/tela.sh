#!/bin/bash
while IFS= read -r linha; do
    linha="${linha%$'\r'}"
    echo "$(echo -e "\r")[$0]$linha$(echo -e "\r")"
done