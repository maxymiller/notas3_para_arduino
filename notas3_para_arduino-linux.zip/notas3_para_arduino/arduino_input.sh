#/bin/bash

arduino_input="$1"
arduino_serial_begin="115200"

if [ -e "$arduino_input" ]; then
    if [ "$arduino_serial_begin" != "" ]; then
        echo "[$0] para sair do picocom: (ctrl+a) depois (ctrl+x)" 1>&2
        sleep 5
        #while true; do
            echo "$arduino_input" > "memoria/arduino_input"
            picocom -b "$arduino_serial_begin" "$arduino_input"
            echo "" > "memoria/arduino_input"

            #echo "[$0] sair: (ctrl+c)" 1>&2
            #sleep 1
        #done
    else
        echo "[$0] error arduino_serial_begin: $arduino_serial_begin"
    fi
else
    echo "[$0] error input: $arduino_input"
fi