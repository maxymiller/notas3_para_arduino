#!/bin/bash

echo "[$0]"

# <0> <input> <output>

#./arduino_input.sh "$2" | ./arduino_output.sh | ./main.sh "$1" | ./tela.sh || exit 1
cat "$(cat memoria/arduino_input)" | ./arduino_output.sh | ./main.sh "$1" | ./tela.sh || exit 1