#include <Arduino.h>
#include <LiquidCrystal.h>

#include <Preferences.h>
#include <WiFi.h>
//#include <BluetoothSerial.h>
#include <WebServer.h>

#define SPEAKER 18

// lcd
#define LCD_RS 13
#define LCD_E 12
#define LCD_D4 14
#define LCD_D5 27
#define LCD_D6 26
#define LCD_D7 25

Preferences memoria;
//Preferences memoriaBluetooth;
//BluetoothSerial bluetooth;
WebServer servidor(80);

HTTPUpload* upload_arquivo = nullptr;
String upload_linha = "";

void ligar();
void teste();
String shell(String comando, int tipo);
boolean interpretar_linha(String linha);
void redimensionar_programa(int novo_tamanho);
void som_tone(int frequencia);
//void bluetooth_wifi();
//void setBluetoothNome(String nome);
boolean setBluetoothSenha(String senha, String senhaNovo);
void http_root();
void http_shell();
void http_notFound();

class Tela {
private:
  LiquidCrystal lcd;
  bool cursor_ligado = false;
public:
  Tela();

  void ligar();
  void escrever(String texto, int linha);
  void limpa(int linha);
  void cursor_ligar(boolean tipo);
  void cursor_desligar(boolean tipo);
  boolean cursor_esta_ligado();
};
Tela tela;

class Wifi {
private:
  String WIFI_SSID = "";
  String WIFI_PASSWORD = "";
public:
  boolean conecta();
  void set(String uuid, String pass);
  String getIp();
  String getConecta();
  void remoreSave();
};
Wifi wifi;

class HttpServidor {
private:
public:
  void ligar();
  void desligar();
};
HttpServidor httpServidor;

//String programa_frequencia = "";
//String programa_quantidade = "";
struct programa_notas_fq {
  int frequencia;
  int quantidade;
};
programa_notas_fq* programa_notas = nullptr;

int programa_tamanho = 0;
int programa_capacidade = 0;

String programa_nome = "";
float programa_tempo_bloco;
int programa_top_n;
float programa_awk_hz_max;

void setup() {
  Serial.begin(115200);

  // bluetooth
  /*memoriaBluetooth.begin("bluetooth", true);
  String nome = memoriaBluetooth.getString("nome", "");
  if(nome == "") {
    nome = "notas3-ESP32";
  }
  bluetooth.begin(nome);
  String pass = memoriaBluetooth.getString("pass", "");
  if(pass != "") {
    bluetooth.setPin(pass.c_str());
  }
  memoriaBluetooth.end();*/

  pinMode(SPEAKER, OUTPUT);
  ligar();
}

void loop() {
  // bluetooth
  //bluetooth_wifi();

  // http
  servidor.handleClient();

  // serial
  if(Serial.available()) {
    String line = Serial.readStringUntil('\n');
    line.trim();

    Serial.println(shell(line, 0));
  }
}

void ligar(){
  delay(500);
  tela.ligar();
  teste();

  memoria.begin("wifi", true);
  String ssid = memoria.getString("ssid", "");
  String pass = memoria.getString("pass", "");
  if(ssid != "" && pass != "") {
    wifi.set(ssid, pass);

    if(wifi.conecta()) {
      httpServidor.ligar();
    }
  }
  memoria.end();

  delay(3000);
  tela.cursor_ligar(false);
  Serial.println(shell("LIGAR", 0));
  //tela.escrever("READY", 2);
}

void teste() {
  som_tone(1000);
  delay(100);
  som_tone(0);
  delay(50);
  som_tone(1000);
  delay(100);
  som_tone(0);
  delay(150);
  som_tone(2000);
  delay(100);
  som_tone(0);
}

String shell(String comando, int tipo){
  String outMeg = "";
  if(comando != "LIGAR") {
    tela.escrever(comando, 0);
  }
  if(comando == "NEW") {
    //programa_frequencia = "";
    //programa_quantidade = "";
    programa_tamanho = 0;
    programa_capacidade = 0;

    programa_nome = "";
    programa_tempo_bloco = 0.00;
    programa_top_n = 0;
    programa_awk_hz_max = 0.00;

    delete[] programa_notas;
  }else if(comando == "RUN") {
    tela.escrever(programa_nome, 1);
    tela.escrever("RUN", 2);

    float calc = programa_tempo_bloco*1000;

    for (int i = 0; i < programa_tamanho; i++) {
      som_tone(programa_notas[i].frequencia);
      delay(calc*programa_notas[i].quantidade);
    }
    som_tone(0);

  }else if(comando == "LIST") {
    if(tipo == 0) {
      Serial.println("# nome="+programa_nome);
      Serial.println("# tempo_bloco="+String(programa_tempo_bloco));
      Serial.println("# top_n="+String(programa_top_n));
      Serial.println("# awk_hz_max="+String(programa_awk_hz_max));
      Serial.println("# arduino_tamanho="+String(programa_capacidade));
      for(int i = 0; i<programa_tamanho; i++) {
        Serial.println(String(programa_notas[i].frequencia) + " " + String(programa_notas[i].quantidade));
      }
    }else if(tipo == 1) {
      outMeg += "# nome="+programa_nome+"\n";
      outMeg += "# tempo_bloco="+String(programa_tempo_bloco)+"\n";
      outMeg += "# top_n="+String(programa_top_n)+"\n";
      outMeg += "# awk_hz_max="+String(programa_awk_hz_max)+"\n";
      outMeg += "# arduino_tamanho="+String(programa_capacidade)+"\n";
      for(int i = 0; i<programa_tamanho; i++) {
        outMeg += String(programa_notas[i].frequencia) + " " + String(programa_notas[i].quantidade) + "\n";
      }
    }
  }else if(comando.indexOf("SETWIFI ") == 0) {
    String ssid = comando.substring(8);
    tela.escrever(ssid, 1);
    tela.escrever(comando.substring(0, 7), 2);
    Serial.print(String(ssid)+"> ");
    while (!Serial.available()) {
      delay(500);
    }
    String pass = Serial.readStringUntil('\n');
    pass.trim();
    Serial.println();
    wifi.set(ssid, pass);
  }else if(comando == "CONEWIFI") {
    tela.escrever("cone wi-fi.", 2);
    Serial.println("conectando ao wi-fi");
    if(wifi.conecta()) {
      tela.escrever("READY WIFI", 2);
      return "READY WIFI";
    }
    tela.escrever("ERROR WIFI", 2);
    return "ERROR WIFI";
  }else if(comando == "INFOWIFI") {
    Serial.println("wifi: "+wifi.getConecta());
    Serial.println("IP: "+wifi.getIp());
  }else if(comando == "REMOVEWIFI") {
    wifi.remoreSave();
  }else if(comando == "LIGAR") {
    tela.escrever("READY", 2);
    return "LIGADO";
  }else{
    if(comando.indexOf("#") != -1) {
      if(comando.indexOf("nome=") != -1) {
        programa_nome = comando.substring(comando.indexOf("nome=") + 5);
        programa_nome.trim();
        tela.escrever(programa_nome, 1);

      }else if(comando.indexOf("tempo_bloco=") != -1) {
        programa_tempo_bloco = comando.substring(comando.indexOf("tempo_bloco=") + 12).toFloat();
        tela.escrever(String(programa_tempo_bloco), 1);

      }else if(comando.indexOf("top_n=") != -1) {
        programa_top_n = comando.substring(comando.indexOf("top_n=") + 6).toInt();
        tela.escrever(String(programa_top_n), 1);

      }else if(comando.indexOf("awk_hz_max=") != -1) {
        programa_awk_hz_max = comando.substring(comando.indexOf("awk_hz_max=") + 11).toFloat();
        tela.escrever(String(programa_awk_hz_max), 1);

      }else if(comando.indexOf("arduino_tamanho=") != -1) {
        redimensionar_programa(comando.substring(comando.indexOf("arduino_tamanho=") + 16).toInt());
        tela.escrever(String(programa_capacidade), 1);

      }else{
        tela.escrever("ERROR", 2);
        return "ERROR";
      }
    }else{
      //programa_frequencia += "";
      //programa_quantidade += "";
      if (!interpretar_linha(comando)) {
        //tela.escrever("limite: "+String(programa_capacidade), 1);
        tela.escrever("ERROR "+String(programa_tamanho)+"/"+String(programa_capacidade), 2);
        return "ERROR";
      }
    }
  }
  tela.escrever("READY "+String(programa_tamanho)+"/"+String(programa_capacidade), 2);
  return outMeg+"READY";
}

boolean interpretar_linha(String linha) {

  int frequencia;
  int quantidade;

  if(sscanf(linha.c_str(), "%d %d", &frequencia, &quantidade) == 2) {
    if(programa_tamanho < programa_capacidade) {
      programa_notas[programa_tamanho].frequencia = frequencia;

      programa_notas[programa_tamanho].quantidade = quantidade;

      programa_tamanho++;
      return true;
    }
  }
  return false;
}

void redimensionar_programa(int novo_tamanho) {
  programa_notas_fq* novo_programa = new programa_notas_fq[novo_tamanho];

  int copiar = programa_tamanho;

  if(copiar > novo_tamanho) {
    copiar = novo_tamanho;
  }

  for(int i = 0; i<copiar; i++) {
    novo_programa[i] = programa_notas[i];
  }

  delete[] programa_notas;

  programa_notas = novo_programa;
  programa_capacidade = novo_tamanho;

  if(programa_tamanho > novo_tamanho) {
    programa_tamanho = novo_tamanho;
  }
}

void som_tone(int frequencia) {
  if(frequencia > 0) {
    tone(SPEAKER, frequencia);
  }else{
    noTone(SPEAKER);
  }
}

// ----------
// tela
// ----------

Tela::Tela()
  : lcd(LCD_RS, LCD_E, LCD_D4, LCD_D5, LCD_D6, LCD_D7) {
}

void Tela::ligar() {
  lcd.begin(16, 2);
  lcd.clear();
  lcd.setCursor(0, 0);
  escrever("ligado", 0);
}

void Tela::escrever(String texto, int linha) {
  if(linha == 0) {
    // Primeira linha
    limpa(0);
    lcd.setCursor(0, 0);
    lcd.print(texto.substring(0,16));

    // Segunda linha
    if(texto.length() > 16) {
      lcd.setCursor(0, 1);
      lcd.print(texto.substring(16, 32));
    }

  }else if(linha == 1) {
    limpa(1);
    lcd.setCursor(0, 0);
    lcd.print(texto.substring(0, 16));

  }else if(linha == 2) {
    limpa(2);
    lcd.setCursor(0, 1);
    lcd.print(texto.substring(0, 16));
  }
}

void Tela::limpa(int linha) {
  String limpaPrint = "                ";
  if(linha == 0) {
    lcd.clear();
  }else if(linha == 1) {
    lcd.setCursor(0, 0);
    lcd.print(limpaPrint);
  }else if(linha == 2) {
    lcd.setCursor(0, 1);
    lcd.print(limpaPrint);
  }
}

void Tela::cursor_ligar(boolean tipo) {
  if(tipo) {
    lcd.cursor();
  }else{
    lcd.cursor();
    lcd.blink();
  }
  cursor_ligado = true;
}
void Tela::cursor_desligar(boolean tipo) {
  if(tipo) {
    lcd.noCursor();
  }else{
    lcd.noBlink();
    lcd.noCursor();
  }
  cursor_ligado = false;
}
boolean Tela::cursor_esta_ligado() {
  return cursor_ligado;
}

// ----------
// wifi
// ----------

boolean Wifi::conecta() {
  WiFi.begin(
    WIFI_SSID,
    WIFI_PASSWORD
  );

  int loop = 0;
  while(WiFi.status() != WL_CONNECTED && loop < 30) {

    delay(500);
    loop++;
  }

  if(WiFi.status() == WL_CONNECTED) {
    memoria.begin("wifi", false);
    if(WIFI_SSID != memoria.getString("ssid", "") || WIFI_PASSWORD != memoria.getString("pass", "")) {
      memoria.putString("ssid", WIFI_SSID);
      memoria.putString("pass", WIFI_PASSWORD);
    }
    memoria.end();

    return true;
  }
  return false;
}
void Wifi::set(String uuid, String pass) {
  WIFI_SSID = uuid;
  WIFI_PASSWORD = pass;
}
String Wifi::getIp() {
  return WiFi.localIP().toString();
}
String Wifi::getConecta() {
  if(WiFi.status() == WL_CONNECTED) {
    return "tá conectado";
  }else{
    return "não está conectado";
  }
}
void Wifi::remoreSave() {
  memoria.begin("wifi", false);
  memoria.putString("ssid", "");
  memoria.putString("pass", "");
  memoria.end();

  WIFI_SSID = "";
  WIFI_PASSWORD = "";

  WiFi.disconnect(true);
}

// ----------
// bluetooth
// ----------

/*void bluetooth_wifi() {

  if (!bluetooth.available()) {
    return;
  }

  String linha = bluetooth.readStringUntil('\n');
  linha.trim();

  if (linha.indexOf("SETWIFI ") == 0) {

    String ssid = linha.substring(8);
    ssid.trim();

    bluetooth.println("SSID recebido");
    bluetooth.print("SENHA> ");

    while (!bluetooth.available()) {
      delay(10);
    }

    String pass = bluetooth.readStringUntil('\n');
    pass.trim();

    wifi.set(ssid, pass);

    bluetooth.println("conectando ao wi-fi...");

    if (wifi.conecta()) {
      bluetooth.println("READY WIFI");
      bluetooth.println("IP: " + wifi.getIp());
    } else {
      bluetooth.println("ERROR WIFI");
    }
  }

  else if (linha == "INFOWIFI") {

    bluetooth.println("wifi: " + wifi.getConecta());
    bluetooth.println("IP: " + wifi.getIp());

  }

  else if (linha == "REMOVEWIFI") {

    wifi.remoreSave();

    bluetooth.println("WIFI REMOVIDO");

  }

  else if (linha == "CONEWIFI") {

    bluetooth.println("conectando ao wi-fi...");

    if (wifi.conecta()) {
      bluetooth.println("READY WIFI");
      bluetooth.println("IP: " + wifi.getIp());
    } else {
      bluetooth.println("ERROR WIFI");
    }
  }

  else if(linha.indexOf("SETBLUEPASS ") == 0) {
    String pass = linha.substring(12);
    pass.trim();

    bluetooth.print("SENHA> ");

    while (!bluetooth.available()) {
      delay(10);
    }

    String passNovo = bluetooth.readStringUntil('\n');
    passNovo.trim();

    if(setBluetoothSenha(pass, passNovo)) {
      bluetooth.println("Por Favor Reinicia o Arduino...");
    }else{
      bluetooth.println("ERROR: senha errado");
    }
  }

  else if(linha.indexOf("SETBLUENOME ") == 0) {
    String nome = linha.substring(12);
    nome.trim();

    setBluetoothNome(nome);
    bluetooth.println("Por Favor Reinicia o Arduino...");
  }

  else {
    bluetooth.println("ERROR: "+linha);
  }
}

void setBluetoothNome(String nome) {
  memoriaBluetooth.begin("bluetooth", false);
  memoriaBluetooth.putString("nome", nome);
  memoriaBluetooth.end();
}
boolean setBluetoothSenha(String senha, String senhaNovo) {
  memoriaBluetooth.begin("bluetooth", false);
  if(memoriaBluetooth.getString("pass", "") == "" || senha == memoriaBluetooth.getString("pass", "")) {
    if(senha != senhaNovo) {
      memoriaBluetooth.putString("pass", senhaNovo);
      memoriaBluetooth.end();
      return true;
    }
    memoriaBluetooth.end();
    return false;
  }
  memoriaBluetooth.end();
  return false;
}*/

// ----------
// http
// ----------

void HttpServidor::ligar() {
  servidor.on("/", http_root);
  servidor.on("/shell", http_shell);
  servidor.on(
    "/upload",
    HTTP_POST,

    []() {
      servidor.send(
        200,
        "text/html",
        "<h1>Upload concluído</h1>"
        "<p>Notas3 carregado no ESP32.</p>"
        "<a href='/'>Voltar</a>"
      );
    },

    []() {
      HTTPUpload& upload = servidor.upload();

      if (upload.status == UPLOAD_FILE_START) {

        Serial.println(
          "UPLOAD: " + upload.filename
        );
        shell("NEW", 1);
        delay(3000);
      }

      else if (upload.status == UPLOAD_FILE_WRITE) {

        for (size_t i = 0; i < upload.currentSize; i++) {

          char c = upload.buf[i];

          if (c == '\n') {

            shell(upload_linha,1);

            upload_linha = "";

          } else if (c != '\r') {

            upload_linha += c;

          }
        }
      }

      else if (upload.status == UPLOAD_FILE_END) {

        // Processa a última linha caso
        // o arquivo não termine com \n.
        if (upload_linha.length() > 0) {
          //processar_notas3_linha(
            //upload_linha
          //);
          shell(upload_linha, 1);
          upload_linha = "";
        }

        Serial.println(
          "UPLOAD OK: " +
          String(programa_tamanho) +
          "/" +
          String(programa_capacidade)
        );
      }
    }
  );

  servidor.onNotFound(http_notFound);

  servidor.begin();

  /*servidor.onNotFound([]() {
    Serial.print("HTTP 404: ");
    Serial.println(servidor.uri());

    servidor.send(404, "text/plain", "404 - pagina nao encontrada");
  });*/
}
void HttpServidor::desligar() {}

void http_root() {
  String html = "";

  html += "<!DOCTYPE html>";
  html += "<html lang='pt-BR'>";
  html += "<head>";
  html += "<meta charset='UTF-8'>";
  html += "<meta name='viewport' content='width=device-width,initial-scale=1'>";
  html += "<title>notas3 para ESP32</title>";

  html += "<style>";
  html += "body{font-family:Arial;margin:30px;background:#eee;}";
  html += ".card{background:white;padding:20px;margin-bottom:15px;border:1px solid #aaa;}";
  html += "button{padding:10px;margin:4px;}";
  html += "</style>";

  html += "</head>";
  html += "<body>";

  html += "<h1>notas3 para ESP32</h1>";

  html += "<div class='card'>";
  html += "<h2>Wi-Fi</h2>";
  html += "<p>Status: " + wifi.getConecta() + "</p>";
  html += "<p>IP: " + wifi.getIp() + "</p>";
  html += "</div>";

  html += "<div class='card'>";
  html += "<h2>Programa</h2>";
  html += "<p>Nome: " + programa_nome + "</p>";
  html += "<p>Notas: " + String(programa_tamanho) + "</p>";
  html += "<p>Capacidade: " + String(programa_capacidade) + "</p>";
  
  html += "<h2>Enviar notas3</h2>";

  html += "<label>";
  html += "<input type='checkbox' id='personalizar'>";
  html += " Personalizar";
  html += "</label>";

  html += "<p id='informacao'>Nenhum arquivo selecionado.</p>";

  html += "<form";
  html += "  id='formUpload'";
  html += "  action='/upload'";
  html += "  method='POST'";
  html += "  enctype='multipart/form-data'>";

  html += "  <input";
  html += "    type='file'";
  html += "    id='arquivo'";
  html += "    name='arquivo'";
  html += "    accept='.txt'>";

  html += "  <p id='informacao'>Nenhum arquivo selecionado.</p>";

  html += "  <button type='submit'>";
  html += "    Enviar notas3";
  html += "  </button>";

  html += "</form>";

  html += "</div>";

  html += "<div class='card'>";
  html += "<h2>Shell</h2>";

  html += "<form action='/shell' method='GET'>";
  html += "<input name='cmd' placeholder='Comando'>";
  html += "<button type='submit'>Enviar</button>";
  html += "</form>";

  html += "<br>";

  html += "<a href='/shell?cmd=NEW'><button>NEW</button></a>";
  html += "<a href='/shell?cmd=LIST'><button>LIST</button></a>";
  html += "<a href='/shell?cmd=RUN'><button>RUN</button></a>";

  html += "</div>";

  html += "</body>";

  html += "<script>";

  html += "const arquivo = document.getElementById('arquivo');";
  html += "const form = document.getElementById('formUpload');";
  html += "const informacao = document.getElementById('informacao');";
  html += "const personalizar = document.getElementById('personalizar');";

  html += "form.addEventListener('submit', async function(event) {";
  html += "  event.preventDefault();";

  html += "  if (!arquivo.files.length) {";
  html += "    alert('Selecione um arquivo.');";
  html += "    return;";
  html += "  }";

  html += "  const arquivoOriginal = arquivo.files[0];";
  html += "  const texto = await arquivoOriginal.text();";
  html += "  const linhas = texto.split(/\\r?\\n/);";

  html += "  let loop = 0;";

  html += "  for (const linha of linhas) {";
  html += "    if (linha.indexOf('#') === -1 && linha.trim() !== '') {";
  html += "      loop++;";
  html += "    }";
  html += "  }";

  html += "  if (personalizar.checked) {";
  html += "    const novoTexto = '# arduino_tamanho=' + loop + '\\n' + texto;";

  html += "    const novoArquivo = new File(";
  html += "      [novoTexto],";
  html += "      arquivoOriginal.name,";
  html += "      { type: 'text/plain' }";
  html += "    );";

  html += "    const dados = new FormData();";
  html += "    dados.append('arquivo', novoArquivo);";

  html += "    await fetch('/upload', {";
  html += "      method: 'POST',";
  html += "      body: dados";
  html += "    });";

  html += "  } else {";
  html += "    const dados = new FormData();";
  html += "    dados.append('arquivo', arquivoOriginal);";

  html += "    await fetch('/upload', {";
  html += "      method: 'POST',";
  html += "      body: dados";
  html += "    });";
  html += "  }";

  html += "  informacao.textContent = 'Enviado: ' + loop + ' notas';";

  html += "});";

  html += "</script>";

  html += "</html>";

  servidor.send(200, "text/html", html);
}
void http_shell() {
  if (!servidor.hasArg("cmd")) {
    servidor.send(400, "text/plain", "Comando nao informado");
    return;
  }

  String comando = servidor.arg("cmd");

  String resposta = shell(comando, 1);

  servidor.send(200, "text/plain", resposta);
}
void http_notFound() {
  servidor.send(404, "text/plain", "404 - pagina nao encontrada");
}