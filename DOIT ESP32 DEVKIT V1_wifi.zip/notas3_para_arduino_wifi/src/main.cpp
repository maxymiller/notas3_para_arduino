#include <Arduino.h>

#include <Preferences.h>
//#include <BluetoothSerial.h>

//#include <WebServer.h>
#include <ESPAsyncWebServer.h>

// maxymiller lib
#include <maxymiller_lib/Tela.h>
#include <maxymiller_lib/Tela_SSD1306_oled.h>
#include <maxymiller_lib/erroSistema.h>
#include "maxymiller_lib/Wifi.h"

#define SPEAKER 18

// lcd
#define LCD_RS 13
#define LCD_E 12
#define LCD_D4 14
#define LCD_D5 27
#define LCD_D6 26
#define LCD_D7 25

// oled
#define OLED_SDA 32
#define OLED_SCL 33

erroSistema erro;

Preferences memoria;
//Preferences memoriaBluetooth;
//BluetoothSerial bluetooth;

//WebServer servidor(80);
AsyncWebServer servidor(80);

//HTTPUpload* upload_arquivo = nullptr;
String upload_linha = "";

void ligar();
void teste();
String shell(String comando, int tipo);
boolean interpretar_linha(String linha);
void redimensionar_programa(int novo_tamanho);
void som_tone(int frequencia);
void wifi_ico();
void error_ico();
//void bluetooth_wifi();
//void setBluetoothNome(String nome);
//boolean setBluetoothSenha(String senha, String senhaNovo);
void http_root(AsyncWebServerRequest *request);
void http_shell(AsyncWebServerRequest *request);
void http_notFound(AsyncWebServerRequest *request);

Tela tela(16, 2, 1, 1);
Tela_SSD1306_oled tela2(1, 1);

Wifi wifi;

class HttpServidor {
private:
public:
  void ligar();
  void desligar();
};
HttpServidor httpServidor;

class AppLoop {
private:
  unsigned long uptimeLong = 0;
  unsigned long uptimeMemoriaLong = 0;
  boolean onAppBoolean = false;
  int appN = 0;
  float calc = 0;
  int loopInt = 0;
public:
  void loop();
  int uptime();
  int uptimeMais(int mais);
  void ligarApp(int app);
  void desligarApp();
  boolean onApp();
  void shellRun();
};
AppLoop appLoop;

//String programa_frequencia = "";
//String programa_quantidade = "";
struct programa_notas_fq {
  int frequencia;
  int quantidade;
};
programa_notas_fq* programa_notas = nullptr;

int programa_tamanho = 0;
int programa_capacidade = 0;

bool upload_processando = false;
int upload_processado = 0;
int upload_total = 0;

String programa_nome = "";
float programa_tempo_bloco;
int programa_top_n;
float programa_awk_hz_max;

boolean wifi_cone = false;
boolean wifi_tela_on = false;

void appLoopTask(void *parameter) {
  while(true) {
    appLoop.loop();
    delay(1);
  }
}

void setup() {
  Serial.begin(115200);

  xTaskCreatePinnedToCore(
    appLoopTask,
    "AppLoop",
    10000,
    NULL,
    1,
    NULL,
    0
  );

  tela.add(LCD_RS, LCD_E, LCD_D4, LCD_D5, LCD_D6, LCD_D7);
  tela2.add(0x3C, OLED_SDA, OLED_SCL);

  String megError = erro.mostrarErroAnterior();
  if(megError != "") {
    Serial.println(megError);

    tela.ligar();
    tela2.ligar();

    tela.escrever(erro.getMensagem(), 0);
    tela2.escrever("", 0);
    error_ico();

    tela2.escrever(String(erro.getMotivo()), 3);
    tela2.escrever(String(erro.getCode()), 4);

    som_tone(500);

    erro.reboot(10);
  }
  erro.removeErroAnterior();

  // bluetooth
  /*memoriaBluetooth.begin("bluetooth", true);
  String nome = memoriaBluetooth.getString("nome", "");
  if(nome == "") {
    nome = "notas3-ESP32";
  }
  bluetooth.begin(nome);
  String pass = memoriaBluetooth.getString("pass", "");
  if(pass != "") {
    bluetooth.setPin(pass.c_str());
  }
  memoriaBluetooth.end();*/

  pinMode(SPEAKER, OUTPUT);
  ligar();
}

void loop() {
  // bluetooth
  //bluetooth_wifi();

  // http
  // ESPAsyncWebServer não usa servidor.handleClient();

  if ((wifi.getIp() != "0.0.0.0" && !wifi_cone) || (wifi.getIp() == "0.0.0.0" && wifi_cone) || !wifi_tela_on) {
    tela2.escrever(wifi.getIp(), 2);

    if((wifi.getIp() != "0.0.0.0" && !wifi_cone) || (wifi.getIp() == "0.0.0.0" && wifi_cone)) {
      wifi_cone = !wifi_cone;
    }
    wifi_tela_on = true;
  }

  tela.loop();
  //if(!appLoop.onApp()) {
    tela2.loop();
  //}
  //appLoop.loop();

  wifi_ico();

  // serial
  if(Serial.available()) {
    String line = Serial.readStringUntil('\n');
    line.trim();

    Serial.println(shell(line, 0));
  }
}

void ligar(){
  delay(500);
  tela.ligar();
  tela2.ligar();
  teste();

  memoria.begin("wifi", true);
  String ssid = memoria.getString("ssid", "");
  String pass = memoria.getString("pass", "");
  if(ssid != "") {
    wifi.set(ssid, pass);

    if(wifi.conecta(memoria)) {
      httpServidor.ligar();
    }
  }
  memoria.end();

  delay(3000);
  tela.cursor_ligar(false);
  tela2.escrever("", 0);
  tela2.cursor_ligar(false);
  Serial.println(shell("LIGAR", 0));
  //tela.escrever("READY", 2);
  tela2.escrever("", 1);
}

void teste() {
  som_tone(1000);
  delay(100);
  som_tone(0);
  delay(50);
  som_tone(1000);
  delay(100);
  som_tone(0);
  delay(150);
  som_tone(2000);
  delay(100);
  som_tone(0);
}

// ----------
// app loop
// ----------

void AppLoop::loop() {
  if(appN == 1) {
    shellRun();
  }
}
int AppLoop::uptime() {
  uptimeLong = millis();
  return int(uptimeLong);
}
int AppLoop::uptimeMais(int mais) {
  uptimeMemoriaLong = uptimeLong + mais;
  return int(uptimeMemoriaLong);
}
void AppLoop::ligarApp(int app) {
  appN = app;
  onAppBoolean = true;
  if(appN == 1) {
    calc = programa_tempo_bloco*1000;
  }
}
void AppLoop::desligarApp() {
  appN = 0;
  onAppBoolean = false;
  calc = 0;
  loopInt = 0;
  tela.escrever("READY", 2);
  Serial.println("READY");
}
boolean AppLoop::onApp() {
  return onAppBoolean;
}
void AppLoop::shellRun() {
  uptime();

  if(uptimeLong >= uptimeMemoriaLong) {
    if(loopInt < programa_tamanho) {
      som_tone(programa_notas[loopInt].frequencia);

      uptimeMais(calc*programa_notas[loopInt].quantidade);

      loopInt++;
    }else{
      som_tone(0);
      desligarApp();
    }
  }
}

String shell(String comando, int tipo){
  if(!appLoop.onApp()) {
    String outMeg = "";
    if(comando != "LIGAR") {
      tela.escrever(comando, 0);
    }
    if(comando == "NEW") {
      //programa_frequencia = "";
      //programa_quantidade = "";
      programa_tamanho = 0;

      programa_nome = "";
      programa_tempo_bloco = 0.00;
      programa_top_n = 0;
      programa_awk_hz_max = 0.00;

      redimensionar_programa(0);
    }else if(comando == "RUN") {
      tela.escrever(programa_nome, 1);
      tela.escrever("RUN", 2);

      appLoop.ligarApp(1);
      return "RUN";

    }else if(comando == "LIST") {
      if(tipo == 0) {
        Serial.println("# nome="+programa_nome);
        Serial.println("# tempo_bloco="+String(programa_tempo_bloco));
        Serial.println("# top_n="+String(programa_top_n));
        Serial.println("# awk_hz_max="+String(programa_awk_hz_max));
        Serial.println("# arduino_tamanho="+String(programa_capacidade));
        for(int i = 0; i<programa_tamanho; i++) {
          Serial.println(String(programa_notas[i].frequencia) + " " + String(programa_notas[i].quantidade));
        }
      }else if(tipo == 1) {
        outMeg += "# nome="+programa_nome+"\n";
        outMeg += "# tempo_bloco="+String(programa_tempo_bloco)+"\n";
        outMeg += "# top_n="+String(programa_top_n)+"\n";
        outMeg += "# awk_hz_max="+String(programa_awk_hz_max)+"\n";
        outMeg += "# arduino_tamanho="+String(programa_capacidade)+"\n";
        for(int i = 0; i<programa_tamanho; i++) {
          outMeg += String(programa_notas[i].frequencia) + " " + String(programa_notas[i].quantidade) + "\n";
        }
      }
    }else if(comando.indexOf("SETWIFI ") == 0) {
      if(tipo == 0) {
        String ssid = wifi.getSSID(comando.substring(8).toInt());
        if(ssid != "") {
          tela.escrever(ssid, 1);
          tela.escrever(comando.substring(0, 7), 2);
          Serial.print(String(ssid)+"> ");
          while (!Serial.available()) {
            delay(500);
          }
          String pass = Serial.readStringUntil('\n');
          pass.trim();
          Serial.println();
          if(pass != ".") {
            wifi.set(ssid, pass);
          }else{
            wifi.set(ssid, "");
          }
        }else{
          return "ERROR";
        }
      }else{
        tela.escrever("ErrorPermiProto", 2);
        return "você não tem permissão para usar com esse protocolo";
      }
    }else if(comando == "LISTWIFI") {
      if(tipo == 0) {
        wifi.list();
      }else{
        tela.escrever("ErrorPermiProto", 2);
        return "você não tem permissão para usar com esse protocolo";
      }
    }else if(comando == "CONEWIFI") {
      if(tipo == 0) {
        tela.escrever("cone wi-fi.", 2);
        Serial.println("conectando ao wi-fi");
        if(wifi.conecta(memoria)) {
          tela.escrever("READY WIFI", 2);
          return "READY WIFI";
        }
        tela.escrever("ERROR WIFI", 2);
        return "ERROR WIFI";
      }else{
        tela.escrever("ErrorPermiProto", 2);
        return "você não tem permissão para usar com esse protocolo";
      }
    }else if(comando == "INFOWIFI") {
      if(tipo == 0) {
        Serial.println("wifi: "+wifi.getConecta());
        Serial.println("IP: "+wifi.getIp());
        Serial.println("RSSI: "+wifi.getRssi());
      }else{
        tela.escrever("ErrorPermiProto", 2);
        return "você não tem permissão para usar com esse protocolo";
      }
    }else if(comando == "REMOVEWIFI") {
      if(tipo == 0) {
        wifi.remoreSave(memoria);
      }else{
        tela.escrever("ErrorPermiProto", 2);
        return "você não tem permissão para usar com esse protocolo";
      }
    }else if(comando == "LIGAR") {
      tela.escrever("READY", 2);
      return "LIGADO";
    }else{
      if(comando.indexOf("#") != -1) {
        String errorMeg = "memoria lotou";
        erro.salvarErroApp(errorMeg);
        if(comando.indexOf("nome=") != -1) {
          erro.salvarErroApp(errorMeg+" nome=");
          programa_nome = comando.substring(comando.indexOf("nome=") + 5);
          programa_nome.trim();
          tela.escrever(programa_nome, 1);

        }else if(comando.indexOf("tempo_bloco=") != -1) {
          erro.salvarErroApp(errorMeg+" tempo_bloco=");
          programa_tempo_bloco = comando.substring(comando.indexOf("tempo_bloco=") + 12).toFloat();
          tela.escrever(String(programa_tempo_bloco), 1);

        }else if(comando.indexOf("top_n=") != -1) {
          erro.salvarErroApp(errorMeg+" top_n=");
          programa_top_n = comando.substring(comando.indexOf("top_n=") + 6).toInt();
          tela.escrever(String(programa_top_n), 1);

        }else if(comando.indexOf("awk_hz_max=") != -1) {
          erro.salvarErroApp(errorMeg+" awk_hz_max=");
          programa_awk_hz_max = comando.substring(comando.indexOf("awk_hz_max=") + 11).toFloat();
          tela.escrever(String(programa_awk_hz_max), 1);

        }else if(comando.indexOf("arduino_tamanho=") != -1) {
          erro.salvarErroApp("redimensionar memoria");
          redimensionar_programa(comando.substring(comando.indexOf("arduino_tamanho=") + 16).toInt());
          tela.escrever(String(programa_capacidade), 1);

        }else{
          erro.removeErroAnterior();
          tela.escrever("ERROR", 2);
          return "ERROR";
        }
        erro.removeErroAnterior();
      }else{
        //programa_frequencia += "";
        //programa_quantidade += "";
        if (!interpretar_linha(comando)) {
          //tela.escrever("limite: "+String(programa_capacidade), 1);
          tela.escrever("ERROR "+String(programa_tamanho)+"/"+String(programa_capacidade), 2);
          return "ERROR";
        }
      }
    }
    tela.escrever("READY "+String(programa_tamanho)+"/"+String(programa_capacidade), 2);
    //tela2.escrever(String(programa_tamanho)+"/"+String(programa_capacidade), 3);
    return outMeg+"READY";
  }else{
    return "NOT READY";
  }
}

boolean interpretar_linha(String linha) {

  int frequencia;
  int quantidade;

  if(sscanf(linha.c_str(), "%d %d", &frequencia, &quantidade) == 2) {
    if(programa_tamanho < programa_capacidade) {
      programa_notas[programa_tamanho].frequencia = frequencia;

      programa_notas[programa_tamanho].quantidade = quantidade;

      programa_tamanho++;
      return true;
    }
  }
  return false;
}

void redimensionar_programa(int novo_tamanho) {
  programa_notas_fq* novo_programa = new programa_notas_fq[novo_tamanho];

  int copiar = programa_tamanho;

  if(copiar > novo_tamanho) {
    copiar = novo_tamanho;
  }

  for(int i = 0; i<copiar; i++) {
    novo_programa[i] = programa_notas[i];
  }

  delete[] programa_notas;

  programa_notas = novo_programa;
  programa_capacidade = novo_tamanho;

  if(programa_tamanho > novo_tamanho) {
    programa_tamanho = novo_tamanho;
  }
}

void som_tone(int frequencia) {
  if(frequencia > 0) {
    tone(SPEAKER, frequencia);
  }else{
    noTone(SPEAKER);
  }
}

// ----------
// wifi ico
// ----------

void wifi_ico() {
  String rssi = wifi.getRssi();
  rssi = rssi.substring(0, rssi.indexOf("dBm")-1);
  int rssiInt = rssi.toInt();
  //tela2.escrever(rssi, 3);

  for(int i = 0; i <= 1; i++) {
    tela2.desenharia_pixels(0, 11, (5+i)+5 , 12, (5+i)+5, false);
  }

  for(int i = 0; i < 6; i++) {
    int telaY = (i*1)-5;
    int telaX = (i*1);
    tela2.desenharia_pixels(0, 8-telaX, 4-telaY, 11-telaX, 2-telaY, false);

    tela2.desenharia_pixels(0, 11-telaX, 2-telaY, 11+telaX, 2-telaY, false);
  
    tela2.desenharia_pixels(0, 11+telaX, 2-telaY, 15+telaX, 4-telaY, false);
  }

  if(wifi.getIp() == "0.0.0.0") {
    return;
  }
  for(int i = 0; i <= 1; i++) {
    tela2.desenharia_pixels(0, 11, (5+i)+5 , 12, (5+i)+5, true);
  }

  int wifi_rssi = 0;

  for(int i = 0; i < 5; i++) {
    if(rssiInt >= (-90+(10*i))) {
      wifi_rssi++;
    }
  }
  if(rssiInt >= -30) {
    wifi_rssi++;
  }

  for(int i = 0; i < wifi_rssi; i++) {
    int telaY = (i*1)-5;
    int telaX = (i*1);
    tela2.desenharia_pixels(0, 8-telaX, 4-telaY, 11-telaX, 2-telaY, true);

    tela2.desenharia_pixels(0, 11-telaX, 2-telaY, 11+telaX, 2-telaY, true);
  
    tela2.desenharia_pixels(0, 11+telaX, 2-telaY, 15+telaX, 4-telaY, true);
  }
  
}

// ----------
// error ico
// ----------

void error_ico() {
  int ax = 3;
  int ay = 10;
  for(int y = 0; y < 2; y++) {
    int y1 = y*10;
    for(int i = 0; i <= 4; i++) {
      tela2.desenharia_pixels(0, ax, (ay+y1)+i, ax+4, (ay+y1)+i, true);
    }
  }
  for(int y = 0; y < 5; y++) {
    int x1 = 10;
    int y1 = -10;
    for(int i = 0; i <= 4; i++) {
      if(y == 0 || y == 4) {
        tela2.desenharia_pixels(0, (ax+x1)+x1, ((ay+(5*(y+1)))+i)+y1, ((ax+x1)+4)+x1, ((ay+(5*(y+1)))+i)+y1, true);
      }else{
        tela2.desenharia_pixels(0, (ax+x1-5)+x1, ((ay+(5*(y+1)))+i)+y1, ((ax+x1-5)+4)+x1, ((ay+(5*(y+1)))+i)+y1, true);
      }
    }
  }
}

// ----------
// bluetooth
// ----------

/*void bluetooth_wifi() {

  if (!bluetooth.available()) {
    return;
  }

  String linha = bluetooth.readStringUntil('\n');
  linha.trim();

  if (linha.indexOf("SETWIFI ") == 0) {

    String ssid = linha.substring(8);
    ssid.trim();

    bluetooth.println("SSID recebido");
    bluetooth.print("SENHA> ");

    while (!bluetooth.available()) {
      delay(10);
    }

    String pass = bluetooth.readStringUntil('\n');
    pass.trim();

    wifi.set(ssid, pass);

    bluetooth.println("conectando ao wi-fi...");

    if (wifi.conecta()) {
      bluetooth.println("READY WIFI");
      bluetooth.println("IP: " + wifi.getIp());
    } else {
      bluetooth.println("ERROR WIFI");
    }
  }

  else if (linha == "INFOWIFI") {

    bluetooth.println("wifi: " + wifi.getConecta());
    bluetooth.println("IP: " + wifi.getIp());

  }

  else if (linha == "REMOVEWIFI") {

    wifi.remoreSave();

    bluetooth.println("WIFI REMOVIDO");

  }

  else if (linha == "CONEWIFI") {

    bluetooth.println("conectando ao wi-fi...");

    if (wifi.conecta()) {
      bluetooth.println("READY WIFI");
      bluetooth.println("IP: " + wifi.getIp());
    } else {
      bluetooth.println("ERROR WIFI");
    }
  }

  else if(linha.indexOf("SETBLUEPASS ") == 0) {
    String pass = linha.substring(12);
    pass.trim();

    bluetooth.print("SENHA> ");

    while (!bluetooth.available()) {
      delay(10);
    }

    String passNovo = bluetooth.readStringUntil('\n');
    passNovo.trim();

    if(setBluetoothSenha(pass, passNovo)) {
      bluetooth.println("Por Favor Reinicia o Arduino...");
    }else{
      bluetooth.println("ERROR: senha errado");
    }
  }

  else if(linha.indexOf("SETBLUENOME ") == 0) {
    String nome = linha.substring(12);
    nome.trim();

    setBluetoothNome(nome);
    bluetooth.println("Por Favor Reinicia o Arduino...");
  }

  else {
    bluetooth.println("ERROR: "+linha);
  }
}

void setBluetoothNome(String nome) {
  memoriaBluetooth.begin("bluetooth", false);
  memoriaBluetooth.putString("nome", nome);
  memoriaBluetooth.end();
}
boolean setBluetoothSenha(String senha, String senhaNovo) {
  memoriaBluetooth.begin("bluetooth", false);
  if(memoriaBluetooth.getString("pass", "") == "" || senha == memoriaBluetooth.getString("pass", "")) {
    if(senha != senhaNovo) {
      memoriaBluetooth.putString("pass", senhaNovo);
      memoriaBluetooth.end();
      return true;
    }
    memoriaBluetooth.end();
    return false;
  }
  memoriaBluetooth.end();
  return false;
}*/

// ----------
// http
// ----------

void HttpServidor::ligar() {
  servidor.on("/", HTTP_GET, [](AsyncWebServerRequest *request) {
    http_root(request);
  });
  servidor.on("/shell", HTTP_GET, [](AsyncWebServerRequest *request) {
    http_shell(request);
  });
  servidor.on("/upload-status", HTTP_GET, []
    (AsyncWebServerRequest *request) {

    String resposta = "{";

    resposta += "\"processando\":";
    resposta += upload_processando ? "true" : "false";

    resposta += ",\"processado\":";
    resposta += String(upload_processado);

    resposta += ",\"total\":";
    resposta += String(upload_total);

    resposta += "}";

    request -> send(
      200,
      "application/json",
      resposta
    );
  });
  servidor.on(
    "/upload",
    HTTP_POST,

    [](AsyncWebServerRequest *request) {
      request -> send(
        200,
        "text/html",
        "<h1>Upload concluído</h1>"
        "<p>Notas3 carregado no ESP32.</p>"
        "<a href='/'>Voltar</a>"
      );
    },

    [](
      AsyncWebServerRequest *request,
      String filename,
      size_t index,
      uint8_t *data,
      size_t len,
      bool final
    ) {

      if (index == 0) {

        Serial.println(
          "UPLOAD: " + filename
        );
        
        upload_processando = true;
        upload_processado = 0;
        upload_total = 0;
        upload_linha = "";

        shell("NEW", 1);
      }

      if (len > 0) {

        for (size_t i = 0; i < len; i++) {

          char c = data[i];

          if (c == '\n') {

            if (upload_linha.indexOf("#") == -1) {
              upload_processado++;
            }

            shell(upload_linha,1);
            if(upload_linha.indexOf("#") != -1) {
              upload_total = programa_capacidade;
            }
            upload_linha = "";

          } else if (c != '\r') {
            upload_linha += c;
          }
        }
      }

      if (final) {
        // Processa a última linha caso
        // o arquivo não termine com \n.
        if (upload_linha.length() > 0) {
          //processar_notas3_linha(
            //upload_linha
          //);
          shell(upload_linha, 1);
          upload_linha = "";
        }

        upload_processado = programa_tamanho;
        upload_total = programa_capacidade;
        upload_processando = false;

        Serial.println(
          "UPLOAD OK: " +
          String(programa_tamanho) +
          "/" +
          String(programa_capacidade)
        );
      }
    }
  );

  servidor.onNotFound(http_notFound);

  servidor.begin();

  /*servidor.onNotFound([]() {
    Serial.print("HTTP 404: ");
    Serial.println(servidor.uri());

    servidor.send(404, "text/plain", "404 - pagina nao encontrada");
  });*/
}
void HttpServidor::desligar() {}

void http_root(AsyncWebServerRequest *request) {
  String html = "";

  html += "<!DOCTYPE html>";
  html += "<html lang='pt-BR'>";
  html += "<head>";
  html += "<meta charset='UTF-8'>";
  html += "<meta name='viewport' content='width=device-width,initial-scale=1'>";
  html += "<title>notas3 para ESP32</title>";

  html += "<style>";
  html += "body{font-family:Arial;margin:30px;background:#eee;}";
  html += ".card{background:white;padding:20px;margin-bottom:15px;border:1px solid #aaa;}";
  html += "button{padding:10px;margin:4px;}";

  html += ".progresso{";
  html += "display:none;";
  html += "margin-top:15px;";
  html += "}";

  html += ".barra{";
  html += "width:100%;";
  html += "height:25px;";
  html += "background:#ddd;";
  html += "border:1px solid #999;";
  html += "}";

  html += ".barraProgresso{";
  html += "width:0%;";
  html += "height:100%;";
  html += "background:#4caf50;";
  html += "text-align:center;";
  html += "color:white;";
  html += "line-height:25px;";
  html += "transition:width 0.2s ease;";
  html += "box-sizing:border-box;";
  html += "}";

  html += ".carregando{";
  html += "display:none;";
  html += "padding:10px;";
  html += "margin-top:10px;";
  html += "background:#fff3cd;";
  html += "border:1px solid #ffe69c;";
  html += "}";

  html += "</style>";

  html += "</head>";
  html += "<body>";

  html += "<h1>notas3 para ESP32</h1>";

  html += "<div class='card'>";
  html += "<h2>Wi-Fi</h2>";
  html += "<p>Status: " + wifi.getConecta() + "</p>";
  html += "<p>IP: " + wifi.getIp() + "</p>";
  html += "<p>RSSI: " + wifi.getRssi() + "</p>";
  html += "</div>";

  html += "<div class='card'>";
  html += "<h2>Programa</h2>";
  html += "<p>Nome: " + programa_nome + "</p>";
  html += "<p>Notas: " + String(programa_tamanho) + "</p>";
  html += "<p>Capacidade: " + String(programa_capacidade) + "</p>";

  html += "<h2>Enviar notas3</h2>";

  html += "<label>";
  html += "<input type='checkbox' id='personalizar'>";
  html += " Personalizar (adiciona \"# arduino_tamanho=\")";
  html += "</label>";

  html += "<p id='informacao'>Nenhum arquivo selecionado.</p>";

  html += "<form";
  html += " id='formUpload'";
  html += " action='/upload'";
  html += " method='POST'";
  html += " enctype='multipart/form-data'>";

  html += "<input";
  html += " type='file'";
  html += " id='arquivo'";
  html += " name='arquivo'";
  html += " accept='.txt'>";

  html += "<br><br>";

  html += "<button id='botaoEnviar' type='submit'>";
  html += "Enviar notas3";
  html += "</button>";

  html += "</form>";

  html += "<div id='carregando' class='carregando'>";
  html += "Enviando arquivo...";
  html += "</div>";

  html += "<h3>Upload do arquivo</h3>";

  html += "<div id='progresso' class='progresso'>";
  html += "<div class='barra'>";
  html += "<div id='barraProgresso' class='barraProgresso'>0%</div>";
  html += "</div>";
  html += "<p id='textoProgresso'>0%</p>";
  html += "</div>";

  html += "<h3>Processamento no Arduino</h3>";

  html += "<div id='progressoArduino' class='progresso'>";
  html += "<div class='barra'>";
  html += "<div id='barraArduino' class='barraProgresso'>0%</div>";
  html += "</div>";
  html += "<p id='textoArduino'>0 / 0 notas</p>";
  html += "</div>";

  html += "</div>";

  html += "<div class='card'>";
  html += "<h2>Shell</h2>";

  html += "<p>Status: ";
  if(appLoop.onApp()) {
    html += "NOT READY";
  }else{
    html += "READY";
  }
  html += "</p>";

  html += "<form action='/shell' method='GET'>";
  html += "<input name='cmd' placeholder='Comando'>";
  html += "<button type='submit'>Enviar</button>";
  html += "</form>";

  html += "<br>";

  html += "<a href='/shell?cmd=NEW'><button>NEW</button></a>";
  html += "<a href='/shell?cmd=LIST'><button>LIST</button></a>";
  html += "<a href='/shell?cmd=RUN'><button>RUN</button></a>";

  html += "</div>";

  // JavaScript
  html += "<script>";

  html += "const arquivo = document.getElementById('arquivo');";
  html += "const form = document.getElementById('formUpload');";
  html += "const informacao = document.getElementById('informacao');";
  html += "const personalizar = document.getElementById('personalizar');";

  // Mostrar arquivo selecionado
  html += "arquivo.addEventListener('change', function() {";
  html += "  if (arquivo.files.length) {";
  html += "    informacao.textContent = 'Arquivo: ' + arquivo.files[0].name;";
  html += "  } else {";
  html += "    informacao.textContent = 'Nenhum arquivo selecionado.';";
  html += "  }";
  html += "});";

  // Enviar
  html += "form.addEventListener('submit', function(event) {";
  html += "  event.preventDefault();";

  html += "  if (!arquivo.files.length) {";
  html += "    alert('Selecione um arquivo.');";
  html += "    return;";
  html += "  }";

  html += "  const arquivoOriginal = arquivo.files[0];";

  html += "  arquivoOriginal.text().then(function(texto) {";

  html += "    const linhas = texto.split(/\\r?\\n/);";
  html += "    let loop = 0;";

  html += "    for (const linha of linhas) {";
  html += "      if (linha.trim() !== '' && linha.indexOf('#') === -1) {";
  html += "        loop++;";
  html += "      }";
  html += "    }";

  html += "    let enviarArquivo = arquivoOriginal;";

  html += "    if (personalizar.checked) {";

  html += "      const novoTexto =";
  html += "        '# arduino_tamanho=' + loop + '\\n' + texto;";

  html += "      enviarArquivo = new File(";
  html += "        [novoTexto],";
  html += "        arquivoOriginal.name,";
  html += "        { type: 'text/plain' }";
  html += "      );";

  html += "    }";

  html += "    const dados = new FormData();";
  html += "    dados.append('arquivo', enviarArquivo);";

  html += "    const xhr = new XMLHttpRequest();";

  html += "    const botaoEnviar = document.getElementById('botaoEnviar');";

  html += "    botaoEnviar.disabled = true;";
  html += "    botaoEnviar.textContent = 'Enviando...';";

  html += "    const carregando = document.getElementById('carregando');";
  html += "    const progresso = document.getElementById('progresso');";
  html += "    const barra = document.getElementById('barraProgresso');";
  html += "    const textoProgresso = document.getElementById('textoProgresso');";

  html += "    const progressoArduino = document.getElementById('progressoArduino');";
  html += "    const barraArduino = document.getElementById('barraArduino');";
  html += "    const textoArduino = document.getElementById('textoArduino');";

  html += "    progressoArduino.style.display = 'block';";

  html += "    carregando.style.display = 'block';";
  html += "    progresso.style.display = 'block';";

  html += "    xhr.upload.addEventListener('progress', function(event) {";

  html += "      if (event.lengthComputable) {";

  html += "        const porcentagem = Math.round(";
  html += "          (event.loaded / event.total) * 100";
  html += "        );";

  html += "        barra.style.width = porcentagem + '%';";
  html += "        barra.textContent = porcentagem + '%';";
  html += "        textoProgresso.textContent =";
  html += "          'Enviando: ' + porcentagem + '%';";

  html += "      }";

  html += "    });";

  html += "    xhr.onload = function() {";

  html += "      if (xhr.status >= 200 && xhr.status < 300) {";
  
  html += "        barra.style.width = '100%';";
  html += "        barra.textContent = '100%';";

  html += "        textoProgresso.textContent =";
  html += "          'Concluído: ' + loop + ' notas';";

  html += "        carregando.textContent =";
  html += "          'Upload concluído!';";

  html += "        botaoEnviar.disabled = false;";
  html += "        botaoEnviar.textContent = 'Enviar notas3';";

  html += "        setTimeout(function() {";
  html += "          window.location.reload();";
  html += "        }, 1000);";

  html += "      } else {";

  html += "        carregando.textContent = 'Erro ao enviar arquivo.';";
  html += "        botaoEnviar.disabled = false;";
  html += "        botaoEnviar.textContent = 'Enviar notas3';";

  html += "      }";

  html += "    };";

  html += "    xhr.onerror = function() {";
  html += "      carregando.textContent = 'Erro de conexão.';";
  html += "      botaoEnviar.disabled = false;";
  html += "      botaoEnviar.textContent = 'Enviar notas3';";
  html += "    };";

  html += "    xhr.open('POST', '/upload', true);";
  html += "    xhr.send(dados);";

  html += "    const intervaloArduino = setInterval(function() {";

  html += "      fetch('/upload-status')";
  html += "        .then(function(resposta) {";
  html += "          return resposta.json();";
  html += "        })";
  html += "        .then(function(status) {";

  html += "          if (status.total > 0) {";

  html += "            const porcentagemArduino = Math.min(";
  html += "              100,";
  html += "              Math.round((status.processado / status.total) * 100)";
  html += "            );";

  html += "            barraArduino.style.width = porcentagemArduino + '%';";
  html += "            barraArduino.textContent = porcentagemArduino + '%';";

  html += "            textoArduino.textContent =";
  html += "              status.processado + ' / ' + status.total + ' notas';";
  html += "          }";

  html += "          if (!status.processando && status.total > 0) {";

  html += "            barraArduino.style.width = '100%';";
  html += "            barraArduino.textContent = '100%';";

  html += "            textoArduino.textContent =";
  html += "              status.processado + ' / ' + status.total + ' notas - concluído';";

  html += "            clearInterval(intervaloArduino);";

  html += "          }";

  html += "        })";

  html += "        .catch(function(erro) {";
  html += "          console.log('Erro status Arduino:', erro);";
  html += "        });";

  html += "    }, 200);";

  html += "  });";

  html += "});";

  html += "</script>";

  html += "</body>";
  html += "</html>";

  request -> send(200, "text/html", html);
}
void http_shell(AsyncWebServerRequest *request) {
  if (!request -> hasParam("cmd")) {
    request -> send(400, "text/plain", "Comando nao informado");
    return;
  }

  String comando = request -> getParam("cmd") -> value();

  String resposta = shell(comando, 1);

  request -> send(200, "text/plain; charset=utf-8", resposta);
}
void http_notFound(AsyncWebServerRequest *request) {
  request -> send(404, "text/plain", "404 - pagina nao encontrada");
}