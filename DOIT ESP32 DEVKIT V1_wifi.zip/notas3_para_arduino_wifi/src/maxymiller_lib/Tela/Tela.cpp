#include "maxymiller_lib/Tela.h"

Tela::Tela(
  int LCD_RS, int LCD_E, int LCD_D4, int LCD_D5, int LCD_D6, int LCD_D7,
  int x, int y
)
  : lcd(LCD_RS, LCD_E, LCD_D4, LCD_D5, LCD_D6, LCD_D7) {
    TELA_X = x;
    TELA_Y = y;
}

void Tela::ligar() {
  lcd.begin(TELA_X, TELA_Y);
  TELA_LINE = new String[TELA_Y];
  for(int i = 0; i<TELA_X; i++) {
    TELA_LIMPA+=" ";
  }
  escrever("ligado", 0);
}

void Tela::loop() {
  if(millis() >= UPTIME_MEMORIA) {
    UPTIME_MEMORIA = millis()+500;

    int lineMax = 0;
    for(int i = 0; i < TELA_Y; i++) {
      if(TELA_LINE[i].length() > 16 && TELA_LINE[i].length() > lineMax) {
        lineMax = TELA_LINE[i].length();
      }
    }

    if(LOOP > 5) {

      limpa(0);
      for(int y = 0; y < TELA_Y; y++) {
        lcd.setCursor(0, y);
        if(LOOP < lineMax) {
          if(TELA_LINE[y].length() >= TELA_X) {
            lcd.print(TELA_LINE[y].substring(LOOP-5, TELA_X+(LOOP-5)));
          }else{
            escrever(TELA_LINE[y], y+1);
          }
        }else{
          escrever(TELA_LINE[y], y+1);
        }
      }
    }
    if(lineMax > 16 && LOOP >= lineMax) {
      LOOP = 0;
    }
    LOOP++;
  }
}

void Tela::escrever(String texto, int linha) {
  if(linha == 0) {
    limpa(0);
    for(int y = 0; y < (texto.length()/16)+1; y++) {
      if(y < TELA_Y) {
        lcd.setCursor(0, y);
        lcd.print(texto.substring(TELA_X*y, TELA_X*(y+1)));
        TELA_LINE[y] = texto.substring(TELA_X*y, TELA_X*(y+1));
      }else{
        break;
      }
    }
  }if(linha > 0 && linha <= TELA_Y) {
    limpa(linha);
    lcd.setCursor(0, linha-1);
    lcd.print(texto.substring(0, TELA_X));
    TELA_LINE[linha-1] = texto.substring(0, TELA_X);
  }
}

void Tela::limpa(int linha) {
  if(linha == 0) {
    lcd.clear();
  }else if(linha == 1) {
    lcd.setCursor(0, 0);
    lcd.print(TELA_LIMPA);
  }else if(linha == 2) {
    lcd.setCursor(0, 1);
    lcd.print(TELA_LIMPA);
  }
}

void Tela::cursor_ligar(boolean tipo) {
  if(tipo) {
    lcd.cursor();
    lcd.noBlink();
  }else{
    lcd.cursor();
    lcd.blink();
  }
  cursor_ligado = true;
}
void Tela::cursor_desligar() {
  lcd.noBlink();
  lcd.noCursor();
  cursor_ligado = false;
}
boolean Tela::cursor_esta_ligado() {
  return cursor_ligado;
}