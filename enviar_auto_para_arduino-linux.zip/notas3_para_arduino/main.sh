#!/bin/bash

arquivoin="$1"
arquivoout="$2"

cmd_tit="[$0]"
cmd_error="$cmd_tit ($0 \"<in>\" \"<out>\")"$'\n'"error:"

cmd_arduino_new="NEW"
cmd_arduino_ready="READY"
#cmd_arduino_stop="STOP"
cmd_arduino_run="RUN"
cmd_arduino_error="ERROR"
cmd_arduino_notas3_tamanho="# arduino_tamanho="

if [ -f "$arquivoin" ]; then
	if [ -e "$arquivoout" ]; then
		loop=0
		loop2=0
		list=""
		while IFS= read -r line || [[ -n "$line" ]]; do
			((loop++))
			[[ -z "$line" ]] && continue
			((loop2++))
			if [ "$list" == "" ]; then
				list="$loop"
			else
				list="$list:$loop"
			fi
		done < "$arquivoin"
		
		echo "$cmd_tit pera por sinal..."
		echo "$cmd_arduino_new" > "$arquivoout"
		while [ "$(cat "$arquivoout")" != "$cmd_arduino_ready" ]; do
			sleep 1
		done
		echo "$cmd_tit arduino: READY."
		echo "$cmd_tit ver tamanho do arquivo..."

		#echo "$cmd_tit pera por sinal..."
		echo "$cmd_arduino_notas3_tamanho$(
			awk '
				/^#/{
					next
				}
				
				{
					if(!inicio) {
						i=0
					}
					i++
					
					if(!inicio) {
						inicio = 1
						next
					}
				}END{
					if(inicio)
						print i
				}
			' <(
				for ((i=1; i<=loop2; i++)); do
					sed -n "$(echo "$list" | cut -d: -f$i)p" "$arquivoin"
				done
			)
		)" > "$arquivoout"

		echo "$cmd_tit pera por sinal..."

		while [ "$(cat "$arquivoout")" != "$cmd_arduino_ready" ]; do
			sleep 1
		done
		
		for ((i=1; i<=loop2; i++)); do
			timeoutloop=0
			while true; do
				echo "$cmd_tit ($i/$loop2): $(sed -n "$(echo "$list" | cut -d: -f$i)p" "$arquivoin")"
				echo "$cmd_tit enviar para o arduino..."
				echo "$(sed -n "$(echo "$list" | cut -d: -f$i)p" "$arquivoin")" > "$arquivoout"
				echo "$cmd_tit pera por sinal..."
				while [[ "$(cat "$arquivoout")" != "$cmd_arduino_ready" && "$(cat "$arquivoout")" != "$cmd_arduino_error" ]]; do
					if [ "$timeoutloop" -lt "100" ]; then
						sleep 0.01
						((timeoutloop++))
					else
						sleep 1
					fi
				done
				if [ "$(cat "$arquivoout")" == "$cmd_arduino_error" ]; then
					echo "$cmd_tit: error do arduino..."
				fi
				if [ "$(cat "$arquivoout")" == "$cmd_arduino_ready" ]; then
					break
				fi
			done
		done
		echo "$cmd_arduino_run" > "$arquivoout"
		
		#echo "$cmd_tit: $loop"
		#echo "$cmd_tit: $loop2"
	else
		echo "$cmd_error output: $arquivoout"
	fi
else
	echo "$cmd_error input: $arquivoin"
fi
