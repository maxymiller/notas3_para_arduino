#!/bin/bash

arduino_input="$(cat memoria/arduino_input)"

if [ -e "$arduino_input" ]; then
    echo "[$0] para sair (ctrl+c)"
    while true; do
        read in
        echo "$in" > "$arduino_input"
    done
else
    exit 1
fi