#include <Arduino.h>
#include <LiquidCrystal.h>

#define SPEAKER 18

// lcd
#define LCD_RS 13
#define LCD_E 12
#define LCD_D4 14
#define LCD_D5 27
#define LCD_D6 26
#define LCD_D7 25


void ligar();
void teste();
String shell(String comando);
boolean interpretar_linha(String linha);
void redimensionar_programa(int novo_tamanho);
void som_tone(int frequencia);

class Tela {
private:
  LiquidCrystal lcd;
  bool cursor_ligado = false;
public:
  Tela();

  void ligar();
  void escrever(String texto, int linha);
  void limpa(int linha);
  void cursor_ligar(boolean tipo);
  void cursor_desligar(boolean tipo);
  boolean cursor_esta_ligado();
};
Tela tela;

//String programa_frequencia = "";
//String programa_quantidade = "";
struct programa_notas_fq {
  int frequencia;
  int quantidade;
};
programa_notas_fq* programa_notas = nullptr;

int programa_tamanho = 0;
int programa_capacidade = 0;

String programa_nome = "";
float programa_tempo_bloco;
int programa_top_n;
float programa_awk_hz_max;

void setup() {
  Serial.begin(115200);
  pinMode(SPEAKER, OUTPUT);
  ligar();
}

void loop() {
  if(!Serial.available()) {
    return;
  }

  String line = Serial.readStringUntil('\n');
  line.trim();

  //Serial.println(line);
  //delay(1000);

  Serial.println(shell(line));
}

void ligar(){
  tela.ligar();
  teste();
  delay(3000);
  tela.cursor_ligar(false);
  Serial.println(shell("LIGAR"));
  //tela.escrever("READY", 2);
}

void teste() {
  som_tone(1000);
  delay(100);
  som_tone(0);
  delay(50);
  som_tone(1000);
  delay(100);
  som_tone(0);
  delay(150);
  som_tone(2000);
  delay(100);
  som_tone(0);
}

String shell(String comando){
  if(comando != "LIGAR") {
    tela.escrever(comando, 0);
  }
  if(comando == "NEW") {
    //programa_frequencia = "";
    //programa_quantidade = "";
    programa_tamanho = 0;

    programa_nome = "";
    programa_tempo_bloco = 0.00;
    programa_top_n = 0;
    programa_awk_hz_max = 0.00;
  }else if(comando == "RUN") {
    tela.escrever(programa_nome, 1);
    tela.escrever("RUN", 2);

    float calc = programa_tempo_bloco*1000;

    for (int i = 0; i < programa_tamanho; i++) {
      som_tone(programa_notas[i].frequencia);
      delay(calc*programa_notas[i].quantidade);
    }
    som_tone(0);

  }else if(comando == "LIST") {
    Serial.println("# nome="+programa_nome);
    Serial.println("# tempo_bloco="+String(programa_tempo_bloco));
    Serial.println("# top_n="+String(programa_top_n));
    Serial.println("# awk_hz_max="+String(programa_awk_hz_max));
    Serial.println("# arduino_tamanho="+String(programa_capacidade));
    for(int i = 0; i<programa_tamanho; i++) {
      Serial.println(String(programa_notas[i].frequencia) + " " + String(programa_notas[i].quantidade));
    }
  }else if(comando == "LIGAR") {
    tela.escrever("READY", 2);
    return "LIGADO";
  }else{
    if(comando.indexOf("#") != -1) {
      if(comando.indexOf("nome=") != -1) {
        programa_nome = comando.substring(comando.indexOf("nome=") + 5);
        programa_nome.trim();
        tela.escrever(programa_nome, 1);

      }else if(comando.indexOf("tempo_bloco=") != -1) {
        programa_tempo_bloco = comando.substring(comando.indexOf("tempo_bloco=") + 12).toFloat();
        tela.escrever(String(programa_tempo_bloco), 1);

      }else if(comando.indexOf("top_n=") != -1) {
        programa_top_n = comando.substring(comando.indexOf("top_n=") + 6).toInt();
        tela.escrever(String(programa_top_n), 1);

      }else if(comando.indexOf("awk_hz_max=") != -1) {
        programa_awk_hz_max = comando.substring(comando.indexOf("awk_hz_max=") + 11).toFloat();
        tela.escrever(String(programa_awk_hz_max), 1);

      }else if(comando.indexOf("arduino_tamanho=") != -1) {
        redimensionar_programa(comando.substring(comando.indexOf("arduino_tamanho=") + 16).toInt());
        tela.escrever(String(programa_capacidade), 1);

      }else{
        tela.escrever("ERROR", 2);
        return "ERROR";
      }
    }else{
      //programa_frequencia += "";
      //programa_quantidade += "";
      if (!interpretar_linha(comando)) {
        //tela.escrever("limite: "+String(programa_capacidade), 1);
        tela.escrever("ERROR "+String(programa_tamanho)+"/"+String(programa_capacidade), 2);
        return "ERROR";
      }
    }
  }
  tela.escrever("READY "+String(programa_tamanho)+"/"+String(programa_capacidade), 2);
  return "READY";
}

boolean interpretar_linha(String linha) {

  int frequencia;
  int quantidade;

  if(sscanf(linha.c_str(), "%d %d", &frequencia, &quantidade) == 2) {
    if(programa_tamanho < programa_capacidade) {
      programa_notas[programa_tamanho].frequencia = frequencia;

      programa_notas[programa_tamanho].quantidade = quantidade;

      programa_tamanho++;
      return true;
    }
  }
  return false;
}

void redimensionar_programa(int novo_tamanho) {
  programa_notas_fq* novo_programa = new programa_notas_fq[novo_tamanho];

  int copiar = programa_tamanho;

  if(copiar > novo_tamanho) {
    copiar = novo_tamanho;
  }

  for(int i = 0; i<copiar; i++) {
    novo_programa[i] = programa_notas[i];
  }

  delete[] programa_notas;

  programa_notas = novo_programa;
  programa_capacidade = novo_tamanho;

  if(programa_tamanho > novo_tamanho) {
    programa_tamanho = novo_tamanho;
  }
}

void som_tone(int frequencia) {
  if(frequencia > 0) {
    tone(SPEAKER, frequencia);
  }else{
    noTone(SPEAKER);
  }
}

Tela::Tela()
  : lcd(LCD_RS, LCD_E, LCD_D4, LCD_D5, LCD_D6, LCD_D7) {
}

void Tela::ligar() {
  lcd.begin(16, 2);
  lcd.clear();
  lcd.setCursor(0, 0);
  escrever("ligado", 0);
}

void Tela::escrever(String texto, int linha) {
  if(linha == 0) {
    // Primeira linha
    limpa(0);
    lcd.setCursor(0, 0);
    lcd.print(texto.substring(0,16));

    // Segunda linha
    if(texto.length() > 16) {
      lcd.setCursor(0, 1);
      lcd.print(texto.substring(16, 32));
    }

  }else if(linha == 1) {
    limpa(1);
    lcd.setCursor(0, 0);
    lcd.print(texto.substring(0, 16));

  }else if(linha == 2) {
    limpa(2);
    lcd.setCursor(0, 1);
    lcd.print(texto.substring(0, 16));
  }
}

void Tela::limpa(int linha) {
  String limpaPrint = "                ";
  if(linha == 0) {
    lcd.clear();
  }else if(linha == 1) {
    lcd.setCursor(0, 0);
    lcd.print(limpaPrint);
  }else if(linha == 2) {
    lcd.setCursor(0, 1);
    lcd.print(limpaPrint);
  }
}

void Tela::cursor_ligar(boolean tipo) {
  if(tipo) {
    lcd.cursor();
  }else{
    lcd.cursor();
    lcd.blink();
  }
  cursor_ligado = true;
}
void Tela::cursor_desligar(boolean tipo) {
  if(tipo) {
    lcd.noCursor();
  }else{
    lcd.noBlink();
    lcd.noCursor();
  }
  cursor_ligado = false;
}
boolean Tela::cursor_esta_ligado() {
  return cursor_ligado;
}